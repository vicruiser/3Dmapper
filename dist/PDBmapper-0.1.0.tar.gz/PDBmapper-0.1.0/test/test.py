#!/usr/bin/env python3

import scripts.PDBmapper

#python3 PDBmapper.py -protid ENSP00000482258 -vep s