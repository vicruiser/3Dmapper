is.xyz <- function(x)
  inherits(x, "xyz")
