is.mol2 <- function(x)
  inherits(x, "mol2")
