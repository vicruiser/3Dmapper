"mktrj" <- function(...)
  UseMethod("mktrj")
