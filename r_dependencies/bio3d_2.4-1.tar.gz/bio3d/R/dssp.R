"dssp" <- function(...)
  UseMethod("dssp")
