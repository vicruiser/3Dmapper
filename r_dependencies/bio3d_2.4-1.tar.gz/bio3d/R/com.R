"com" <- function(...)
  UseMethod("com")
