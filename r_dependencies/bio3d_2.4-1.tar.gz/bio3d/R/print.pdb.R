print.pdb <- function(x, printseq=TRUE, ...) {
  ## Print a summary of basic PDB object features
  y <- summary.pdb(x, printseq=printseq, ...)
}
