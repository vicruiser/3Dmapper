vmd <- function(...)
  UseMethod("vmd")
